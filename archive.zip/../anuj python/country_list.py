b=["India","USA","Russia","UK","Pakistan","Srilanka","Australia","Bangladesh","Singapor","Thailand","Dubai","Saudi Arabia","Poland"]
