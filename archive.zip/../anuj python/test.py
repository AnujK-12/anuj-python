import tkinter

print(dir(tkinter))